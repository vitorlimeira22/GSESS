import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# fonte: https://politicaporinteiro.org/desastres/
df = pd.read_csv("desastres_brasil.csv")

# Gráfico de barras para contagem de ocorrência por tipo de desastre
plt.figure(figsize=(12, 7))
sns.countplot(data=df, y='desastre', order=df['desastre'].value_counts().index[:10], hue='desastre', palette='viridis', legend=False)
plt.title('Top 10 Tipos de Desastres no Brasil (2019-2025)')
plt.xlabel('Número de Ocorrências')
plt.ylabel('Tipo de Desastre')
plt.tight_layout()
plt.savefig('top_10_desastres.png')
plt.close()

# Gráfico de barras para contagem de ocorrência por estado
plt.figure(figsize=(12, 7))
sns.countplot(data=df, y='uf', order=df['uf'].value_counts().index, palette='plasma')
plt.title('Contagem de Desastres por Estado no Brasil (2019-2025)')
plt.xlabel('Número de Ocorrências')
plt.ylabel('Estado (UF)')
plt.tight_layout()
plt.savefig('desastres_por_estado.png')
plt.close()


